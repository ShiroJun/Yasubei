﻿using UnityEngine;
using System.Collections;

public class WoodenCrateRed : MonoEX {

	// Use this for initialization
	void Start () {
        Invoke("Destroy", 1);
    }

}
